function callAPI() {
  fetch("http://127.0.0.1:8000/api/hello/")
    .then(response => response.json())
    .then(data => {
      document.getElementById("response").innerText = data.message;
    })
    .catch(err => {
      document.getElementById("response").innerText = "Error: " + err;
    });
}
